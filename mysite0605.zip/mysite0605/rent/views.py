from django.shortcuts import render
from django.http import HttpResponse
from .models import Rent,Rent2,Rent3
from django.shortcuts import render_to_response

def index(request):
	return render(request , 'web_final/index.html')

def rent(request):
	rent = Rent.objects.all()
	return render_to_response('web_final/rent.html' , locals())

def about(request):
	return render(request , 'web_final/about.html' )

def contact(request):
	return render(request , 'web_final/contact.html' )

def rent_2(request):
	rent2 = Rent2.objects.all()
	return render_to_response('web_final/rent_2.html' , locals())

def rent_3(request):
	rent3 = Rent3.objects.all()
	return render_to_response('web_final/rent_3.html' , locals())