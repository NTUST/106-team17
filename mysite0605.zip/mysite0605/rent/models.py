from django.db import models



class Rent(models.Model):
	website = models.CharField(max_length=200 , blank = True)
	image=models.ImageField(null = True , blank = True )
	comment = models.CharField(max_length=200 , blank = True)
	housetype = models.CharField(max_length=200 , blank = True)
	price = models.DecimalField(max_digits=7 , decimal_places = 0)
	text = models.CharField(max_length = 300,blank = True)
	address = models.CharField(max_length = 50 , blank = True)

	def __str__(self):
		return self.address


class Rent2(models.Model):
	website = models.CharField(max_length=200 , blank = True)
	image=models.ImageField(null = True , blank = True )
	comment = models.CharField(max_length=200 , blank = True)
	housetype = models.CharField(max_length=200 , blank = True)
	price = models.DecimalField(max_digits=7 , decimal_places = 0)
	text = models.CharField(max_length = 300,blank = True)
	address = models.CharField(max_length = 50 , blank = True)

	def __str__(self):
		return self.address

class Rent3(models.Model):
	website = models.CharField(max_length=200 , blank = True)
	image=models.ImageField(null = True , blank = True )
	comment = models.CharField(max_length=200 , blank = True)
	housetype = models.CharField(max_length=200 , blank = True)
	price = models.DecimalField(max_digits=7 , decimal_places = 0)
	text = models.CharField(max_length = 300,blank = True)
	address = models.CharField(max_length = 50 , blank = True)

	def __str__(self):
		return self.address

