from django.contrib import admin

from .models import Rent,Rent2,Rent3



admin.site.register(Rent )
admin.site.register(Rent2)
admin.site.register(Rent3 )

